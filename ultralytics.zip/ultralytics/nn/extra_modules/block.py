import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from timm.layers import DropPath

from ..modules.conv import Conv
from ..modules.block import C2f

__all__ = ['CIGLA', 'SNIr', 'GSConvE', 'CIGLA_Block']


def window_partition(x, window_size):
    """
    将特征图划分为多个窗口
    x: (B, H, W, C) -> nW*B, window_size, window_size, C
    """
    B, H, W, C = x.shape
    x = x.view(B, H // window_size, window_size, W // window_size, window_size, C)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, C)
    return windows


def window_reverse(windows, window_size, H, W):
    """
    将窗口合并回特征图
    windows: (nW*B, window_size, window_size, C) -> B, H, W, C
    """
    B = int(windows.shape[0] / (H * W / window_size / window_size))
    x = windows.view(B, H // window_size, W // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x


class GRN(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gamma = nn.Parameter(torch.zeros(1, 1, 1, dim))
        self.beta = nn.Parameter(torch.zeros(1, 1, 1, dim))

    def forward(self, x):
        Gx = torch.norm(x, p=2, dim=(1, 2), keepdim=True)
        Nx = Gx / (Gx.mean(dim=-1, keepdim=True) + 1e-6)
        return self.gamma * (x * Nx) + x + self.beta


class CIGLA_Block(nn.Module):
    def __init__(self, trans_dim, num_heads=4, window_size=8, kernel_size=13, mlp_ratio=4., drop_path=0., **kwargs):
        super().__init__()
        self.dim = trans_dim
        self.num_heads = num_heads
        self.window_size = window_size
        self.head_dim = self.dim // self.num_heads
        self.scale = self.head_dim ** -0.5

        self.context_generator = nn.Sequential(
            nn.AdaptiveAvgPool2d(7), nn.Conv2d(self.dim, self.dim, 1), nn.GELU())

        self.norm = nn.LayerNorm(self.dim)
        self.qkv_proj = nn.Linear(self.dim, self.dim * 3)
        self.attn_proj = nn.Linear(self.dim, self.dim)

        self.lepe = nn.Sequential(
            nn.Conv2d(self.dim, self.dim, kernel_size, padding=kernel_size // 2, groups=self.dim, bias=False),
            nn.BatchNorm2d(self.dim))

        mlp_hidden_dim = int(self.dim * mlp_ratio)
        self.ffn = nn.Sequential(
            nn.LayerNorm(self.dim), nn.Linear(self.dim, mlp_hidden_dim), GRN(mlp_hidden_dim),
            nn.GELU(), nn.Linear(mlp_hidden_dim, self.dim))
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def _forward_core(self, x_2d):
        B, C, H, W = x_2d.shape
        x = x_2d.permute(0, 2, 3, 1)

        ctx = self.context_generator(x_2d)
        ctx = rearrange(ctx, 'b c h w -> b (h w) c')

        x_windows = window_partition(x, self.window_size)
        B_w, win_h, win_w, _ = x_windows.shape  # B_w = B * nW

        x_norm = self.norm(x_windows)
        q, k, v = self.qkv_proj(x_norm).chunk(3, dim=-1)

        ctx_info = self.norm(ctx).mean(dim=1, keepdim=True)
        ctx_info_expanded = ctx_info.unsqueeze(1).repeat(B_w // B, 1, 1, 1).view(-1, 1, C)

        k = rearrange(k, 'b h w c -> b (h w) c') + ctx_info_expanded
        v = rearrange(v, 'b h w c -> b (h w) c') + ctx_info_expanded

        q = rearrange(q, 'b h w (g d) -> b g (h w) d', g=self.num_heads, h=win_h, w=win_w)
        k = rearrange(k, 'b n (g d) -> b g n d', g=self.num_heads)
        v = rearrange(v, 'b n (g d) -> b g n d', g=self.num_heads)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)

        attn_windows = rearrange(attn @ v, 'b g (h w) d -> b h w (g d)', h=win_h, w=win_w)
        attn_windows = self.attn_proj(attn_windows)

        attn_out = window_reverse(attn_windows, self.window_size, H, W)

        lepe_out = self.lepe(x_2d).permute(0, 2, 3, 1)

        return attn_out + lepe_out

    def _forward_ffn(self, x):
        x_norm = self.ffn[0](x)
        ffn_in = self.ffn[1](x_norm)
        grn_out = self.ffn[2](ffn_in)
        ffn_gelu = self.ffn[3](grn_out)
        ffn_out = self.ffn[4](ffn_gelu)
        return ffn_out

    def forward(self, x):
        x_rearranged = x.permute(0, 2, 3, 1)

        core_out = self._forward_core(x)
        x = x_rearranged + self.drop_path(core_out)

        ffn_out = self._forward_ffn(x)
        x = x + self.drop_path(ffn_out)

        return x.permute(0, 3, 1, 2)

class CIGLA(C2f):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        self.m = nn.ModuleList(CIGLA_Block(self.c) for _ in range(n))

class SNIr(nn.Module):
    # local feature aligned refine
    def __init__(self, c1=0):
        super().__init__()
        self.us = nn.Upsample(None, 2, 'nearest')
        c2 = c1
        # self.alpha = 1/(up_f**2)
        # self.smooth = nn.AdaptiveAvgPool2d(1)
        self.liner = nn.Conv2d(c1, c2, 1, 1, 0, bias=True)

    def forward(self, x):
        x1 = 0.25 * self.us(x)
        # a = self.smooth(x1)
        # alpha = self.liner(0.25 * x1)
        return x1 * self.liner(x1).sigmoid()


class GSConvE(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, g=1, d=1, act=True):
        super().__init__()
        c_ = c2 // 2
        self.cv1 = Conv(c1, c_, k, s, None, g, d, act)
        self.cv2 = nn.Sequential(
            nn.Conv2d(c_, c_, 3, 1, 1, bias=False),
            nn.Conv2d(c_, c_, 3, 1, 1, groups=c_, bias=False),
            nn.GELU()
        )

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = self.cv2(x1)
        y = torch.cat((x1, x2), dim=1)
        # shuffle
        y = y.reshape(y.shape[0], 2, y.shape[1] // 2, y.shape[2], y.shape[3])
        y = y.permute(0, 2, 1, 3, 4)
        return y.reshape(y.shape[0], -1, y.shape[3], y.shape[4])